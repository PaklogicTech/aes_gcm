vivado -mode batch -source simulate.tcl
mv xsim*  shits
mv *log   shits
mv *lab   shits
mv x*     shits
mv web* shits

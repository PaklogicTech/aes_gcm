vivado -mode batch -source build_project.tcl 2>&1 | tee syn_impl_blog.txt
